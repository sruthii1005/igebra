const express = require('express');
const app = express();
const PORT = process.env.PORT || 5000;
const bodyParser = require('body-parser');

app.use(bodyParser.json());

const users = [];
const lessons = [
  { id: 1, title: 'Introduction to Algebra', topic: 'Algebra' },
  { id: 2, title: 'Geometry Basics', topic: 'Geometry' },
  { id: 3, title: 'Understanding Fractions', topic: 'Fractions' },
  { id: 4, title: 'Introduction to Calculus', topic: 'Calculus' }
];

// Track completed lessons per user (in-memory)
const userProgress = {};

app.get('/', (req, res) => {
  res.send('Welcome to the Personalized Education Backend!');
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password required.' });
  }
  if (users.find(u => u.username === username)) {
    return res.status(409).json({ message: 'User already exists.' });
  }
  users.push({ username, password });
  res.status(201).json({ message: 'User registered successfully.' });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) {
    return res.status(401).json({ message: 'Invalid credentials.' });
  }
  res.json({ message: 'Login successful.' });
});

app.get('/recommend', (req, res) => {
  // In a real app, use user data and AI/ML here
  const randomLesson = lessons[Math.floor(Math.random() * lessons.length)];
  res.json({ recommendation: randomLesson });
});

app.post('/complete', (req, res) => {
  const { username, lessonId } = req.body;
  if (!username || !lessonId) {
    return res.status(400).json({ message: 'Username and lessonId required.' });
  }
  if (!users.find(u => u.username === username)) {
    return res.status(404).json({ message: 'User not found.' });
  }
  if (!lessons.find(l => l.id === lessonId)) {
    return res.status(404).json({ message: 'Lesson not found.' });
  }
  if (!userProgress[username]) userProgress[username] = [];
  if (!userProgress[username].includes(lessonId)) {
    userProgress[username].push(lessonId);
  }
  res.json({ message: 'Lesson marked as completed.' });
});

app.get('/progress/:username', (req, res) => {
  const { username } = req.params;
  if (!users.find(u => u.username === username)) {
    return res.status(404).json({ message: 'User not found.' });
  }
  const completed = userProgress[username] || [];
  const completedLessons = lessons.filter(l => completed.includes(l.id));
  res.json({ completed: completedLessons });
});

// User profiles: add role (student/teacher) and preferences
// Example: { username, password, role, preferences }

app.post('/profile', (req, res) => {
  const { username, role = 'student', preferences = {} } = req.body;
  const user = users.find(u => u.username === username);
  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }
  user.role = role;
  user.preferences = preferences;
  res.json({ message: 'Profile updated.', user });
});

app.get('/profile/:username', (req, res) => {
  const { username } = req.params;
  const user = users.find(u => u.username === username);
  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }
  res.json({ profile: user });
});

// Teacher dashboard: get all students and their progress
app.get('/dashboard', (req, res) => {
  // Only return students
  const students = users.filter(u => u.role !== 'teacher');
  const dashboard = students.map(u => ({
    username: u.username,
    progress: (userProgress[u.username] || []).map(id => lessons.find(l => l.id === id))
  }));
  res.json({ students: dashboard });
});

// Analytics endpoint: get summary stats for teachers
app.get('/analytics', (req, res) => {
  const totalUsers = users.length;
  const totalStudents = users.filter(u => u.role !== 'teacher').length;
  const totalTeachers = users.filter(u => u.role === 'teacher').length;
  const totalLessons = lessons.length;
  const totalCompletions = Object.values(userProgress).reduce((sum, arr) => sum + arr.length, 0);
  const mostPopularLesson = (() => {
    const counts = {};
    Object.values(userProgress).flat().forEach(id => {
      counts[id] = (counts[id] || 0) + 1;
    });
    let max = 0, lessonId = null;
    for (const id in counts) {
      if (counts[id] > max) {
        max = counts[id];
        lessonId = id;
      }
    }
    return lessons.find(l => l.id === Number(lessonId)) || null;
  })();
  res.json({
    totalUsers,
    totalStudents,
    totalTeachers,
    totalLessons,
    totalCompletions,
    mostPopularLesson
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
