import { useState } from 'react';

export default function Profile() {
  const [username, setUsername] = useState('');
  const [role, setRole] = useState('student');
  const [preferences, setPreferences] = useState('');
  const [profile, setProfile] = useState(null);
  const [message, setMessage] = useState('');

  const fetchProfile = async () => {
    setMessage('');
    setProfile(null);
    try {
      const res = await fetch(`http://localhost:5000/profile/${username}`);
      const data = await res.json();
      if (data.profile) setProfile(data.profile);
      else setMessage(data.message || 'Profile not found.');
    } catch {
      setMessage('Error fetching profile.');
    }
  };

  const updateProfile = async () => {
    setMessage('');
    try {
      const res = await fetch('http://localhost:5000/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, role, preferences: preferences ? { interests: preferences } : {} })
      });
      const data = await res.json();
      setMessage(data.message);
      fetchProfile();
    } catch {
      setMessage('Error updating profile.');
    }
  };

  return (
    <div>
      <h2>User Profile</h2>
      <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} />
      <button onClick={fetchProfile}>View Profile</button>
      <div style={{marginTop: 16}}>
        <select value={role} onChange={e => setRole(e.target.value)}>
          <option value="student">Student</option>
          <option value="teacher">Teacher</option>
        </select>
        <input placeholder="Preferences (e.g. Algebra)" value={preferences} onChange={e => setPreferences(e.target.value)} />
        <button onClick={updateProfile}>Update Profile</button>
      </div>
      {message && <div style={{color: message.includes('Error') ? 'red' : 'green'}}>{message}</div>}
      {profile && (
        <div style={{marginTop: 16}}>
          <strong>Username:</strong> {profile.username}<br />
          <strong>Role:</strong> {profile.role || 'student'}<br />
          <strong>Preferences:</strong> {profile.preferences ? JSON.stringify(profile.preferences) : 'None'}
        </div>
      )}
    </div>
  );
}
