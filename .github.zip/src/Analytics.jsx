import { useState } from 'react';

export default function Analytics() {
  const [stats, setStats] = useState(null);
  const [message, setMessage] = useState('');

  const fetchAnalytics = async () => {
    setMessage('');
    try {
      const res = await fetch('http://localhost:5000/analytics');
      const data = await res.json();
      setStats(data);
    } catch {
      setMessage('Error fetching analytics.');
    }
  };

  return (
    <div>
      <h2>Platform Analytics</h2>
      <button onClick={fetchAnalytics}>Load Analytics</button>
      {message && <div style={{color: 'red'}}>{message}</div>}
      {stats && (
        <div style={{marginTop: 16}}>
          <div><strong>Total Users:</strong> {stats.totalUsers}</div>
          <div><strong>Total Students:</strong> {stats.totalStudents}</div>
          <div><strong>Total Teachers:</strong> {stats.totalTeachers}</div>
          <div><strong>Total Lessons:</strong> {stats.totalLessons}</div>
          <div><strong>Total Lesson Completions:</strong> {stats.totalCompletions}</div>
          <div><strong>Most Popular Lesson:</strong> {stats.mostPopularLesson ? `${stats.mostPopularLesson.title} (${stats.mostPopularLesson.topic})` : 'N/A'}</div>
        </div>
      )}
    </div>
  );
}
