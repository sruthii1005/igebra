import { useState } from 'react';

export default function Progress() {
  const [username, setUsername] = useState('');
  const [progress, setProgress] = useState([]);
  const [lessonId, setLessonId] = useState('');
  const [message, setMessage] = useState('');

  const fetchProgress = async () => {
    setMessage('');
    setProgress([]);
    try {
      const res = await fetch(`http://localhost:5000/progress/${username}`);
      const data = await res.json();
      if (data.completed) setProgress(data.completed);
      else setMessage(data.message || 'No progress found.');
    } catch {
      setMessage('Error fetching progress.');
    }
  };

  const completeLesson = async () => {
    setMessage('');
    try {
      const res = await fetch('http://localhost:5000/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, lessonId: Number(lessonId) })
      });
      const data = await res.json();
      setMessage(data.message);
      fetchProgress();
    } catch {
      setMessage('Error marking lesson complete.');
    }
  };

  return (
    <div>
      <h2>Progress Tracker</h2>
      <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} />
      <button onClick={fetchProgress}>View Progress</button>
      <div style={{marginTop: 16}}>
        <input placeholder="Lesson ID to complete" value={lessonId} onChange={e => setLessonId(e.target.value)} />
        <button onClick={completeLesson}>Mark Complete</button>
      </div>
      {message && <div style={{color: message.includes('Error') ? 'red' : 'green'}}>{message}</div>}
      <ul>
        {progress.map(lesson => (
          <li key={lesson.id}>{lesson.title} ({lesson.topic})</li>
        ))}
      </ul>
    </div>
  );
}
