import { useState } from 'react';

export default function Recommendation() {
  const [recommendation, setRecommendation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchRecommendation = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('http://localhost:5000/recommend');
      const data = await res.json();
      setRecommendation(data.recommendation);
    } catch (err) {
      setError('Could not fetch recommendation.');
    }
    setLoading(false);
  };

  return (
    <div>
      <h2>Get a Personalized Lesson Recommendation</h2>
      <button onClick={fetchRecommendation} disabled={loading}>
        {loading ? 'Loading...' : 'Get Recommendation'}
      </button>
      {recommendation && (
        <div style={{marginTop: 16}}>
          <strong>Lesson:</strong> {recommendation.title} <br />
          <strong>Topic:</strong> {recommendation.topic}
        </div>
      )}
      {error && <div style={{color: 'red'}}>{error}</div>}
    </div>
  );
}
