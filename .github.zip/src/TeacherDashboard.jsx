import { useState } from 'react';

export default function TeacherDashboard() {
  const [dashboard, setDashboard] = useState([]);
  const [message, setMessage] = useState('');

  const fetchDashboard = async () => {
    setMessage('');
    try {
      const res = await fetch('http://localhost:5000/dashboard');
      const data = await res.json();
      if (data.students) setDashboard(data.students);
      else setMessage(data.message || 'No data found.');
    } catch {
      setMessage('Error fetching dashboard.');
    }
  };

  return (
    <div>
      <h2>Teacher Dashboard</h2>
      <button onClick={fetchDashboard}>Load Student Progress</button>
      {message && <div style={{color: 'red'}}>{message}</div>}
      <ul>
        {dashboard.map(student => (
          <li key={student.username} style={{marginBottom: 12}}>
            <strong>{student.username}</strong>
            <ul>
              {student.progress.length === 0 && <li>No lessons completed.</li>}
              {student.progress.map(lesson => (
                <li key={lesson.id}>{lesson.title} ({lesson.topic})</li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
}
