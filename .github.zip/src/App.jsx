import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Register from './Register';
import Login from './Login';
import Recommendation from './Recommendation';
import Progress from './Progress';
import Profile from './Profile';
import TeacherDashboard from './TeacherDashboard';
import Analytics from './Analytics';

function App() {
  const [count, setCount] = useState(0)
  const [page, setPage] = useState('home');

  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <nav>
        <button onClick={() => setPage('home')}>Home</button>
        <button onClick={() => setPage('register')}>Register</button>
        <button onClick={() => setPage('login')}>Login</button>
        <button onClick={() => setPage('recommend')}>Recommendation</button>
        <button onClick={() => setPage('progress')}>Progress</button>
        <button onClick={() => setPage('profile')}>Profile</button>
        <button onClick={() => setPage('dashboard')}>Teacher Dashboard</button>
        <button onClick={() => setPage('analytics')}>Analytics</button>
      </nav>
      {page === 'home' && (
        <>
          <h1>Vite + React</h1>
          <div className="card">
            <button onClick={() => setPage('register')}>Go to Register</button>
            <button onClick={() => setPage('login')}>Go to Login</button>
            <button onClick={() => setPage('recommend')}>Get Recommendation</button>
            <button onClick={() => setPage('progress')}>View Progress</button>
            <button onClick={() => setPage('profile')}>Profile</button>
            <button onClick={() => setPage('dashboard')}>Teacher Dashboard</button>
            <button onClick={() => setPage('analytics')}>Analytics</button>
          </div>
        </>
      )}
      {page === 'register' && <Register />}
      {page === 'login' && <Login />}
      {page === 'recommend' && <Recommendation />}
      {page === 'progress' && <Progress />}
      {page === 'profile' && <Profile />}
      {page === 'dashboard' && <TeacherDashboard />}
      {page === 'analytics' && <Analytics />}
    </>
  )
}

export default App
